# Shared Code para Edge Functions

Este diretório contém código compartilhado entre as Edge Functions.
Você pode criar utilitários, tipos TypeScript, helpers, etc.

## Exemplo de uso:

```typescript
// Em qualquer Edge Function
import { helperFunction } from '../_shared/utils.ts';
```

