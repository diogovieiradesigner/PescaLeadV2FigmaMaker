// Re-export from index.tsx for Supabase CLI compatibility
export * from './index.tsx';

